---
name: Nakshatra
colors:
  surface: '#11131a'
  surface-dim: '#11131a'
  surface-bright: '#373941'
  surface-container-lowest: '#0c0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d1f27'
  surface-container-high: '#282a31'
  surface-container-highest: '#33343c'
  on-surface: '#e2e2ec'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#e2e2ec'
  inverse-on-surface: '#2e3038'
  outline: '#918fa1'
  outline-variant: '#464555'
  surface-tint: '#c2c1ff'
  primary: '#c2c1ff'
  on-primary: '#1900a7'
  primary-container: '#8382ff'
  on-primary-container: '#140094'
  inverse-primary: '#4b47dd'
  secondary: '#bbc3ff'
  on-secondary: '#1e2a6c'
  secondary-container: '#364184'
  on-secondary-container: '#a5b0fb'
  tertiary: '#ffb781'
  on-tertiary: '#4e2600'
  tertiary-container: '#d9781a'
  on-tertiary-container: '#442000'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c2c1ff'
  on-primary-fixed: '#0c006a'
  on-primary-fixed-variant: '#3128c5'
  secondary-fixed: '#dee0ff'
  secondary-fixed-dim: '#bbc3ff'
  on-secondary-fixed: '#041157'
  on-secondary-fixed-variant: '#364184'
  tertiary-fixed: '#ffdcc4'
  tertiary-fixed-dim: '#ffb781'
  on-tertiary-fixed: '#2f1400'
  on-tertiary-fixed-variant: '#6f3800'
  background: '#11131a'
  on-background: '#e2e2ec'
  surface-variant: '#33343c'
typography:
  display-hero:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '300'
    lineHeight: 56px
    letterSpacing: -0.035em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: -0.03em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.025em
  headline-sm:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  label-numeric:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '500'
    lineHeight: 22px
    letterSpacing: -0.01em
  label-numeric-lg:
    fontFamily: JetBrains Mono
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.02em
  micro-badge:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 4px
  space-xs: 8px
  space-sm: 12px
  space-md: 16px
  space-lg: 24px
  space-xl: 32px
  space-2xl: 48px
  space-3xl: 64px
  space-4xl: 96px
  container-max: 1180px
  panel-width: 780px
---

## Brand & Style

This design system delivers a serene, voice-first computational sanctuary for high-intent property discovery in Bengaluru. Rejecting the cognitive overload of legacy real estate portals—which weaponize dense map grids, aggressive badge overlays, and low-fidelity photography—this system frames property discovery as an intimate, focused dialogue.

The interface evokes computational elegance, quiet confidence, and spatial intelligence:
- **Design Style:** Minimalist, editorial precision anchored in a nocturnal palette with zero extraneous ornamentation. 
- **Voice & Tone:** Discreet, calm, analytical, and authoritative. Visual noise is treated as a defect.
- **Key Distinctions:** Uncompromisingly desktop-focused. Completely devoid of global navigation bars, listing image galleries, and interactive maps. Information is communicated through pure typography, deliberate structural pacing, and crisp data density.

## Colors

The palette is engineered specifically for deep-focus nocturnal environments, ensuring high readability without eye strain through disciplined surface layers and purposeful chromatic highlights.

### Hierarchy & Token Application
- **Base Canvas (`#0B0D14`):** Near-black ground with a faint navy undertone, anchoring the desktop experience.
- **Surface Elevation (`#12141D`):** Discrete cards, structural modules, and panels. Rises exactly one tonal step above the background.
- **Structural Stroke (`#1F2230`):** Single-pixel perimeter strokes delineating boundaries without adding visual weight.
- **Text & Content Contrast:**
  - `text-primary` (`#ECEEF5`): Core property metrics, active voice transcripts, key values.
  - `text-secondary` (`#8B90A5`): Analytical metadata, commute durations, locality context.
  - `text-muted` (`#5C607A`): Inactive states, structural markers, micro-units.
- **Accent Gradient & Solvers:**
  - Primary Indigo (`#6D6BFF`) flowing to Periwinkle (`#A9B4FF`). Reserved for voice feedback loops, focus boundaries, primary actions, and directional markers.
- **Semantic Indicators:**
  - `semantic-success` (`#34C77B`): Optimal matches, verified transit routes, within-budget affirmations.
  - `semantic-warning` (`#E8A33D`): Approximate results, straight-line distance approximations, fallback queries.
  - `semantic-error` (`#F0555C`): Network dropouts, microphone disconnects, hard constraints violated.

## Typography

The type system utilizes `Geist` for literary and conversational balance, paired with `JetBrains Mono` for programmatic figures and financial evaluations.

- **Headings:** Set with deliberately negative tracking (`-0.02em` to `-0.035em`) to evoke the precision of a bespoke terminal. Light and regular weights prevent high-contrast dark-mode glare.
- **Financials & Coordinates:** All currency values (`₹`), rental amounts, square footage, and commute metrics strictly enforce tabular lining numerals via `font-variant-numeric: tabular-nums` or `JetBrains Mono` to guarantee vertical column parity across search results.
- **Micro Tags:** Tracked slightly wide (`+0.04em`), rendered in uppercase monospaced text to distinguish system telemetry from conversation copy.

## Layout & Spacing

A desktop-only architecture tuned for intentional focus. Layouts avoid full-width sprawl, maintaining tight conversational corridors surrounded by generous dark-sky breathing room.

### The Concentric Desktop Framework
- **Stage Container:** A centered, constrained corridor capped at `1180px` maximum width, floating within a minimum viewport of `1280px`.
- **Primary Stage (`panel-width: 780px`):** The voice transcript, state feedback, and primary property cards inhabit an uninterrupted central single-column flow.
- **Vertical Rhythm:** Generous vertical padding (`space-3xl` to `space-4xl`) at the viewport zenith and nadir, preventing crowding without relying on traditional headers or footers.
- **Micro Spacing:** Internal card elements align to a strict `8px` spatial grid (`space-xs`, `space-md`, `space-lg`).

## Elevation & Depth

This system intentionally eliminates drop shadows. Traditional Gaussian shadows produce murky halos against near-black backgrounds (`#0B0D14`). Instead, spatial hierarchy is constructed strictly through tonal tiering and perimeter illumination:

- **Elevation Level 0 (Base Ground):** `#0B0D14` canvas.
- **Elevation Level 1 (Structural Containers & Cards):** Surface `#12141D` framed by a uniform `1px` solid border in `#1F2230`.
- **Elevation Level 2 (Active/Hover/Voice Focus):** Surface `#12141D` with border transitioning to a subtle accent tint (`rgba(109, 107, 255, 0.35)`) or an inner structural glow (`inset 0 0 0 1px #6D6BFF`).
- **Depth via Luminosity:** Z-index and importance are communicated by typography lightness (`#ECEEF5` over `#8B90A5`), never by physical elevation or blurs.

## Shapes

The geometric signature is grounded, architectural, and restrained:
- **Primary Surfaces & Cards:** Standardized to a `16px` border radius (`rounded-lg` / value `2`). This matches the organic cadence of speech while preserving structural alignment.
- **Interactive Micro-elements:** Voice trigger rings, contextual search pills, and status markers maintain consistent soft geometric profiles (`8px` to full pill radii depending on interactive scope).
- **Hard Boundaries:** No sharp 90-degree outer containers or brutalist raw edges. The soft curve counterbalances the coldness of the dark canvas.

## Components

### 1. The Voice Scout Aperture
The primary interaction node replacing standard search bars and filters.
- **Idle State:** A subtle `#12141D` interactive disc with a `1px` border in `#1F2230`. Contains an understated wave glyph in `#8B90A5`.
- **Listening / Active State:** Border cycles along a continuous gradient from `#6D6BFF` to `#A9B4FF`. Micro-oscillations in accent color indicate acoustic input without jarring screen displacement.
- **Transcript Readout:** Positioned directly above the aperture in `Geist Display` (`fontSize: 24px`, `#ECEEF5`). Live keywords (e.g., *“Indiranagar”*, *“3 BHK”*, *“Metro walking distance”*) highlight dynamically in `#A9B4FF`.

### 2. Property Result Card
Photos are entirely omitted. Replaced with an information-dense, high-typographic layout.
- **Container:** `#12141D` fill, `16px` border-radius, `1px` `#1F2230` outline, `24px` internal padding.
- **Header:** Neighborhood and project descriptor in `headline-sm` (`#ECEEF5`), paired with a right-aligned financial cluster in `label-numeric-lg` displaying the exact rent/price with tabular `₹` symbols.
- **Commute Telemetry Matrix:** A horizontal key-value cluster showing travel metrics. Uses a 2-pixel inline route indicator:
  - Green (`#34C77B`) with text label `"By Purple Line (22m)"`.
  - Amber (`#E8A33D`) with text label `"Straight-line (4.2km, route pending)"`.
- **Key Specifications:** Monospaced chips (`#0B0D14` background, `1px` `#1F2230` border) documenting floor, carpet area, facing direction, and maintenance overheads.

### 3. Voice Context Filters (Pills)
- Non-interactive visual confirmation of parsed entities.
- Rounded pill (`9999px`), `4px 12px` padding.
- Background: `rgba(109, 107, 255, 0.08)`, border: `1px solid rgba(109, 107, 255, 0.25)`, text: `#A9B4FF` in `body-sm`.

### 4. Semantic Status Banners & System Logs
- Used for query diagnostics, offline state, or low-density match notifications.
- Flat background tint matching 5% semantic color opacity with a `1px` border in full semantic tone.
- Text rendered in `body-sm` with semantic accent color highlights.